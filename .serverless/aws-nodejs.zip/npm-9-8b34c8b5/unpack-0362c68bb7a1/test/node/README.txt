node core buffer tests
